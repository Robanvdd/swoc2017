﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SharpBot.Protocol
{
    public enum Player : int
    {
        None = 0,
        White = 1,
        Black = -1,
    }
}

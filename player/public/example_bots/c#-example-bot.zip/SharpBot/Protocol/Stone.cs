﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SharpBot.Protocol
{
    public enum Stone : int
    {
        None = 0,
        A = 1,
        B = 2,
        C = 3,
    }
}

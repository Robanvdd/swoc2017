/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package testbot;

/**
 *
 * @author SvZ
 */
public enum Direction {
    UP,
    DOWN,
    LEFT,
    RIGHT,
    DIAGONAL_UP,
    DIAGONAL_DOWN
}
